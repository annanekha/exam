package com.example.macstudent.appwidgetsample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//import android.util.Log;

//import org.json.JSONObject;
//
//import java.io.IOException;
//
//import okhttp3.Call;
//import okhttp3.Callback;
//import okhttp3.OkHttpClient;
//import okhttp3.Request;
//import okhttp3.Response;

public class MainActivity extends AppCompatActivity {


    //OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Log.d("JENELLE", "THE APP HAS STARTED!");
//
//
//        Request q = new Request.Builder()
//                .url("https://api.darksky.net/forecast/ff41689fc242d7783a79fab7ae586b2b/37.8267,-122.4233")
//                .build();
//
//        Log.d("JENELLE", "making the call asyncro...");
//
//
//        client.newCall(q).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                Log.d("JENELLE", "failed!");
//            }
//
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                Log.d("JENELLE", "success!!");
//
//                if (response.isSuccessful()) {
//                    String reply = response.body().string();
//
//                    Log.d("JENELLE", reply);
//
//                    // convert to JSON
//                    try {
//                        JSONObject json = new JSONObject(reply);
//
//                        // parse the json
//                        double lat = json.getDouble("latitude");
//                        String timeZone = json.getString("timezone");
//
//                        JSONObject currentWeather = json.getJSONObject("currently");
//                        String conditions = currentWeather.getString("summary");
//
//                        Log.d("JENELLE", "Latitude: " + Double.toString(lat));
//                        Log.d("JENELLE", "Timezone: " + timeZone);
//                        Log.d("JENELLE", "Weather conditions: " + conditions);
//
//                    }
//                    catch (Exception e) {
//                        Log.d("JENELLE", "Error while parsing");
//                    }
//                }
//                else {
//                    Log.d("JENELLE", "there was a problem with the response");
//                }
//
//
//            }
//        });
    }
}






