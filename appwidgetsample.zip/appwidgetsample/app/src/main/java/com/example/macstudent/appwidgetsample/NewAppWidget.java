package com.example.macstudent.appwidgetsample;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * Implementation of App Widget functionality.
 */
public class NewAppWidget extends AppWidgetProvider {

    public static String conditions, t;
    public static double lat;
    public static final OkHttpClient client = new OkHttpClient();



    public static final String PREFERENCES_NAME = "AppWidgetSamplePreferences";

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {


        Log.d("JENELLE", "THE APP HAS STARTED!");


        Request q = new Request.Builder()
                .url("https://api.darksky.net/forecast/ff41689fc242d7783a79fab7ae586b2b/43.6332,-79.4186")
                .build();

//        https://darksky.net/forecast/43.6332,-79.4186/us12/en

        Log.d("JENELLE", "making the call asyncro...");


        client.newCall(q).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("JENELLE", "failed!");
            }


            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d("JENELLE", "success!!");

                if (response.isSuccessful()) {
                    String reply = response.body().string();

                    Log.d("JENELLE", reply);

                    // convert to JSON
                    try {
                        JSONObject json = new JSONObject(reply);

                        // parse the json
//                        lat = json.getDouble("latitude");
//                        t = json.getString("temperature");
                        String timeZone = json.getString("timezone");

                        JSONObject currentWeather = json.getJSONObject("currently");
                     conditions = currentWeather.getString("temperature");


                        Log.d("JENELLE", "Latitude: " + Double.toString(lat));
                        Log.d("JENELLE", "Timezone: " + timeZone);
                        Log.d("JENELLE", "Weather conditions: " + conditions);


                    }
                    catch (Exception e) {
                        Log.d("JENELLE", "Error while parsing");
                    }
                }
                else {
                    Log.d("JENELLE", "there was a problem with the response");
                }


            }
        });

        // PUT ALL LOGIC FOR CONTROLLING THE WIDGET IN HERE


        // Construct the RemoteViews object
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.new_app_widget);

        //-------------------------------------------
        // UI nonsense -> update your textviews


        String time = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date());
        views.setTextViewText(R.id.appwidget_text2, conditions+" °F");


        //how many times have we loaded our widget?

        // 1. GET THE COUNT FROM SP
        //----------------------------------
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        // create a count variable
        int count = prefs.getInt("loadCounter", 0);

        // each time you load the widget, increase the counter
        count = count + 1;


        // 2. UPDATE THE WIDGET UI TO SHOW THE COUNT
        //----------------------------------
        // show the new count in the widget
        views.setTextViewText(R.id.appwidget_text, "Count :  " + count);


        // 3. SAVE THE UPDATED COUNT BACK TO SHARED PREFERENCES
        //----------------------------------
        // save the count to shared preferences
        SharedPreferences.Editor prefEditor = prefs.edit();
        prefEditor.putInt("loadCounter",count);
        prefEditor.apply();

        if(count>=5){

            System.out.println("1. I guess somebody is giving life to a kid. " +
                    "2. Its happening because he/she is dying and need to be saved, human life is worth. " +
                    "3. Its life in the circle.");
        }


        // EVERYTIME YOU PUSH THE BUTTON,
        // RUN THIS FUNCTION AGAIN! THAT"S IT!
        Intent intentUpdate = new Intent(context, NewAppWidget.class);
        intentUpdate.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);

        int[] idArray = new int[]{appWidgetId};
        intentUpdate.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, idArray);

        PendingIntent pendingUpdate = PendingIntent.getBroadcast(
                context, appWidgetId, intentUpdate,
                PendingIntent.FLAG_UPDATE_CURRENT);

        // specifcially, the button click handler is here
        views.setOnClickPendingIntent(R.id.button1, pendingUpdate);




        //-------------------------------------------
        // DO NOT REMOVE THIS! Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {

        // YOU DON"T HAVE TO DO ANYTHING HERE
        // JUST LEAVE IT!

        // --> THIS FUNCTION GETS RUN WHEN YOU LOAD YOUR WIDGET

        // onCreate() -> mainactivity

        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }
}

